## ----setup, include=FALSE-----------------------------------------------------
knitr::opts_chunk$set(collapse = TRUE, comment = "#>", fig.width = 10, fig.height = 6)

## -----------------------------------------------------------------------------
library(ggrank)

ggrank(
  ggrank_products,
  category = product,
  period = year,
  value = sales,
  periods = c(2022, 2024),
  top_n = 5,
  value_header = "Sales"
)

## -----------------------------------------------------------------------------
tied_rates <- data.frame(
  year = rep(c(2020, 2025), each = 5),
  organism = rep(c("A", "B", "C", "D", "E"), 2),
  rate = c(5, 4, 3, 3, 2, 6, 4, 4, 2, 1)
)

ggrank_data(
  tied_rates,
  category = organism,
  period = year,
  value = rate
)

## -----------------------------------------------------------------------------
formatted_rates <- transform(
  tied_rates,
  rate_label = sprintf("%.1f per 100,000", rate)
)

ggrank(
  formatted_rates,
  category = organism,
  period = year,
  value = rate,
  label = rate_label
)

## -----------------------------------------------------------------------------
student_ranks <- data.frame(
  year = rep(c(2024, 2025), each = 4),
  student = rep(c("Asha", "Ben", "Chen", "Dina"), 2),
  institution = "North School",
  rank = c(1, 2, 3, 4, 3, 1, 2, 4)
)

ggrank(
  student_ranks,
  category = student,
  period = year,
  rank = rank,
  group = institution,
  top_n = 4
)

## -----------------------------------------------------------------------------
ggrank(
  ggrank_causes,
  category = cause,
  period = year,
  value = rate,
  rank = rank,
  label = display_value,
  group = cause_group,
  periods = c(1990, 2021),
  top_n = 10,
  value_header = "Rate (95% interval)"
)

## -----------------------------------------------------------------------------
changes <- ggrank_table(
  ggrank_products,
  category = product,
  period = year,
  value = sales,
  periods = c(2022, 2024),
  top_n = 5
)

changes

## -----------------------------------------------------------------------------
ggrank_change(changes, top = 5)

## ----eval=FALSE---------------------------------------------------------------
# ggrank_app()

