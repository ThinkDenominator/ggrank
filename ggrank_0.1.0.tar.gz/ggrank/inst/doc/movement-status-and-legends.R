## ----setup, include=FALSE-----------------------------------------------------
knitr::opts_chunk$set(collapse = TRUE, comment = "#>", fig.width = 9, fig.height = 6)

## -----------------------------------------------------------------------------
library(ggrank)

changes <- ggrank_table(
  ggrank_products, product, year, sales,
  top_n = 5,
  show_transitions = "all"
)

changes[c("category", "from", "to", "rank_from", "rank_to",
          "rank_change", "status")]

## -----------------------------------------------------------------------------
ggrank_change(changes, top = 5)

## -----------------------------------------------------------------------------
ggrank_change(changes, top = 5, comparison = "all")

## -----------------------------------------------------------------------------
ggrank_change(changes, from = 2022, to = 2023, top = 5)

## -----------------------------------------------------------------------------
ggrank_change(changes, top = 8, show_stable = TRUE)

## -----------------------------------------------------------------------------
ggrank_change(
  changes,
  top = 5,
  change_label = "ranks",
  label_wrap = 24
)

## -----------------------------------------------------------------------------
movement_colours <- c(
  riser = "#0072B2",
  faller = "#D55E00",
  stable = "#667085"
)

movement_labels <- c(
  riser = "Moved towards rank 1",
  faller = "Moved away from rank 1",
  stable = "No rank change"
)

ggrank_change(
  changes,
  top = 5,
  palette = movement_colours,
  legend_title = "Movement",
  legend_labels = movement_labels
)

## -----------------------------------------------------------------------------
cause_colours <- c(
  "Communicable" = "#009E73",
  "Injuries" = "#0072B2",
  "Non-communicable" = "#D55E00"
)

cause_labels <- c(
  "Communicable" = "Communicable diseases",
  "Injuries" = "Injuries",
  "Non-communicable" = "Non-communicable diseases"
)

ggrank(
  ggrank_causes, cause, year, rate,
  rank = rank, label = display_value, group = cause_group,
  periods = c(1990, 2021), top_n = 10,
  palette = cause_colours,
  legend_title = "Cause group",
  legend_labels = cause_labels
)

